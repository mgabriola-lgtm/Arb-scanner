const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Proxy endpoint
app.get('/api/odds', async (req, res) => {
  const { apiKey, sport } = req.query;
  if (!apiKey || !sport) return res.status(400).json({ error: 'Missing params' });
  const url = `https://api.the-odds-api.com/v4/sports/${sport}/odds/?apiKey=${apiKey}&regions=us&markets=h2h&oddsFormat=american&bookmakers=fanduel,pinnacle`;
  try {
    const r = await fetch(url);
    const data = await r.json();
    if (!r.ok) return res.status(r.status).json(data);
    res.json(data);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// Serve the frontend
app.get('/', (req, res) => res.send(HTML));

app.listen(PORT, () => console.log(`Running on port ${PORT}`));

const HTML = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>ARB SCANNER</title>
<style>
:root{--bg:#08080d;--s1:#0d0d14;--s2:#111118;--b:#1a1a22;--b2:#1e1e28;--g:#00ff88;--fd:#1493ff;--pin:#e8c84a;--tx:#e8e8f0;--mu:#3a3a4a;--or:#ff6b35}
*{box-sizing:border-box;margin:0;padding:0}
body{background:var(--bg);color:var(--tx);font-family:system-ui,sans-serif;min-height:100vh}
header{border-bottom:1px solid var(--b);padding:12px 16px;position:sticky;top:0;z-index:100;background:rgba(8,8,13,.97);backdrop-filter:blur(16px)}
.hrow{max-width:900px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:10px}
.logo{font-family:monospace;font-size:15px;letter-spacing:4px;font-weight:700;display:flex;align-items:center;gap:8px}
.dot{width:8px;height:8px;border-radius:50%;background:#444;flex-shrink:0;transition:all .3s}
.dot.on{background:var(--g);box-shadow:0 0 10px var(--g)}.dot.scan{background:var(--or);box-shadow:0 0 10px var(--or)}
.badges{display:flex;gap:6px}
.bfd{background:rgba(20,147,255,.1);color:var(--fd);border:1px solid rgba(20,147,255,.2);font-family:monospace;font-size:9px;padding:2px 7px;border-radius:3px;letter-spacing:1px}
.bpin{background:rgba(232,200,74,.1);color:var(--pin);border:1px solid rgba(232,200,74,.2);font-family:monospace;font-size:9px;padding:2px 7px;border-radius:3px;letter-spacing:1px}
.stpill{display:flex;align-items:center;gap:5px;font-family:monospace;font-size:9px;color:var(--mu);letter-spacing:1px}
.sdot{width:6px;height:6px;border-radius:50%;background:#333;transition:all .3s}
.wrap{max-width:900px;margin:0 auto;padding:14px 12px}
.cfg{background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:12px;margin-bottom:14px;display:flex;gap:8px;align-items:flex-end;flex-wrap:wrap}
.fld{display:flex;flex-direction:column;gap:4px;flex:1;min-width:100px}
.fld label{font-family:monospace;font-size:8px;color:var(--mu);letter-spacing:2px;text-transform:uppercase}
.fld input,.fld select{background:var(--s2);border:1px solid var(--b2);color:var(--tx);padding:8px 10px;border-radius:5px;font-family:monospace;font-size:12px;width:100%;outline:none;color-scheme:dark;-webkit-appearance:none}
.fld input:focus,.fld select:focus{border-color:var(--g)}
.btn-g{background:var(--g);color:#000;border:none;padding:8px 14px;border-radius:5px;font-family:monospace;font-size:11px;font-weight:700;letter-spacing:1px;cursor:pointer;white-space:nowrap;align-self:flex-end;-webkit-tap-highlight-color:transparent}
.btn-g:disabled{opacity:.5}
.btn-o{background:transparent;color:#444;border:1px solid var(--b2);padding:8px 12px;border-radius:5px;font-family:monospace;font-size:11px;letter-spacing:1px;cursor:pointer;white-space:nowrap;align-self:flex-end;transition:all .15s;-webkit-tap-highlight-color:transparent}
.btn-o.on{border-color:var(--g);color:var(--g);background:rgba(0,255,136,.06)}
.stats{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:14px}
.scard{background:var(--s1);border:1px solid var(--b);border-radius:8px;padding:10px 12px;position:relative;overflow:hidden}
.scard::before{content:'';position:absolute;top:0;left:0;right:0;height:2px}
.scard.g::before{background:var(--g)}.scard.b::before{background:var(--fd)}.scard.y::before{background:var(--pin)}.scard.o::before{background:var(--or)}
.slbl{font-family:monospace;font-size:8px;color:var(--mu);letter-spacing:2px;text-transform:uppercase;margin-bottom:4px}
.sval{font-family:monospace;font-size:18px;font-weight:700}.sval.g{color:var(--g)}
.filters{display:flex;gap:5px;margin-bottom:10px;flex-wrap:wrap;align-items:center;overflow-x:auto;-webkit-overflow-scrolling:touch}
.fbtn{background:var(--s1);border:1px solid var(--b);color:#333;padding:5px 10px;border-radius:4px;font-family:monospace;font-size:9px;letter-spacing:1px;cursor:pointer;white-space:nowrap;-webkit-tap-highlight-color:transparent}
.fbtn.a{border-color:var(--g);color:var(--g);background:rgba(0,255,136,.05)}
.sortsel{margin-left:auto;background:var(--s1);border:1px solid var(--b);color:var(--tx);padding:5px 8px;border-radius:4px;font-family:monospace;font-size:9px;cursor:pointer;color-scheme:dark;outline:none;-webkit-appearance:none}
.err{background:rgba(255,80,80,.07);border:1px solid rgba(255,80,80,.18);color:#ff8888;padding:10px 12px;border-radius:6px;font-family:monospace;font-size:11px;margin-bottom:12px;line-height:1.6;display:none}
.lu{font-family:monospace;font-size:9px;color:#2a2a35;text-align:right;margin-bottom:10px;letter-spacing:1px;display:none}
.center{text-align:center;padding:50px 16px}
.empty-icon{font-size:32px;opacity:.1;margin-bottom:12px}
.empty-title{font-family:monospace;font-size:13px;letter-spacing:3px;color:#2a2a35;margin-bottom:8px}
.empty-sub{font-size:12px;color:#2a2a35;max-width:320px;line-height:1.8;margin:0 auto}
.spinner-wrap{text-align:center;padding:40px}
.spinner{width:24px;height:24px;border:2px solid var(--b);border-top-color:var(--g);border-radius:50%;animation:spin .7s linear infinite;margin:0 auto 12px}
.spin-lbl{font-family:monospace;font-size:10px;color:#444;letter-spacing:2px}
@keyframes spin{to{transform:rotate(360deg)}}
.list{display:flex;flex-direction:column;gap:8px}
.card{background:var(--s1);border:1px solid var(--b);border-radius:8px;overflow:hidden;animation:fadeUp .25s ease both}
@keyframes fadeUp{from{opacity:0;transform:translateY(5px)}to{opacity:1;transform:translateY(0)}}
.chead{display:flex;align-items:center;padding:11px 12px;gap:12px}
.profit{font-family:monospace;font-weight:700;font-size:18px;color:var(--g);min-width:66px;text-align:right}
.profit.hi{color:#00ffcc}
.evname{font-size:13px;font-weight:500;color:var(--tx);margin-bottom:3px;line-height:1.3}
.evmeta{display:flex;gap:7px;align-items:center;font-family:monospace;font-size:9px;color:var(--mu)}
.stag{background:var(--s2);border:1px solid var(--b);padding:1px 5px;border-radius:3px;font-size:8px;letter-spacing:1px}
.ttime{color:var(--or)}
.legs{display:grid;grid-template-columns:1fr 1fr;border-top:1px solid var(--b)}
.leg{background:var(--s2);padding:10px 12px}
.leg:first-child{border-right:1px solid var(--b)}
.book{font-family:monospace;font-size:9px;font-weight:700;letter-spacing:1px;margin-bottom:5px}
.book.fd{color:var(--fd)}.book.pin{color:var(--pin)}
.pick{font-size:12px;color:var(--tx);margin-bottom:8px;line-height:1.3}
.odds-row{display:flex;justify-content:space-between;align-items:flex-end}
.odds{font-family:monospace;font-size:19px;font-weight:700}
.odds.pos{color:var(--g)}.odds.neg{color:var(--or)}
.stake-box{text-align:right}
.slb{font-family:monospace;font-size:8px;color:var(--mu);letter-spacing:1px}
.sv{font-family:monospace;font-size:13px;font-weight:700;color:var(--tx)}
.cfoot{display:flex;align-items:center;justify-content:space-between;padding:9px 12px;border-top:1px solid var(--b);gap:10px}
.psums{display:flex;gap:14px;flex-wrap:wrap}
.plbl{font-family:monospace;font-size:8px;color:var(--mu);letter-spacing:1px}
.pval{font-family:monospace;font-size:12px;font-weight:700;color:var(--tx)}
.pval.g{color:var(--g)}
.copybtn{background:transparent;border:1px solid var(--b2);color:#333;padding:5px 10px;border-radius:4px;font-family:monospace;font-size:9px;letter-spacing:1px;cursor:pointer;white-space:nowrap;transition:all .15s;-webkit-tap-highlight-color:transparent}
.copybtn.copied{border-color:var(--g);color:var(--g);background:rgba(0,255,136,.06)}
</style>
</head>
<body>
<header>
  <div class="hrow">
    <div class="logo"><div class="dot" id="dot"></div>ARB SCANNER</div>
    <div class="badges"><span class="bfd">FD</span><span class="bpin">PIN</span></div>
    <div class="stpill"><div class="sdot" id="sdot"></div><span id="stxt">IDLE</span></div>
  </div>
</header>
<div class="wrap">
  <div class="cfg">
    <div class="fld" style="flex:2;min-width:140px">
      <label>Odds API Key</label>
      <input type="password" id="apiKey" placeholder="Paste from the-odds-api.com" autocomplete="off" />
    </div>
    <div class="fld" style="max-width:120px">
      <label>Sport</label>
      <select id="sport">
        <option value="americanfootball_nfl">NFL</option>
        <option value="basketball_nba">NBA</option>
        <option value="baseball_mlb">MLB</option>
        <option value="icehockey_nhl">NHL</option>
        <option value="americanfootball_ncaaf">NCAAF</option>
        <option value="basketball_ncaab">NCAAB</option>
        <option value="soccer_usa_mls">MLS</option>
      </select>
    </div>
    <div class="fld" style="max-width:80px">
      <label>Stake $</label>
      <input type="number" id="stake" value="100" min="1" inputmode="numeric" />
    </div>
    <button class="btn-g" id="scanBtn" onclick="scan()">▶ SCAN</button>
    <button class="btn-o" id="autoBtn" onclick="toggleAuto()">⟳ AUTO</button>
  </div>
  <div class="stats">
    <div class="scard g"><div class="slbl">ARBS FOUND</div><div class="sval g" id="sArbs">0</div></div>
    <div class="scard b"><div class="slbl">MARKETS</div><div class="sval" id="sMarkets">0</div></div>
    <div class="scard y"><div class="slbl">MAX PROFIT</div><div class="sval" id="sMax">0.00%</div></div>
    <div class="scard o"><div class="slbl">TOTAL PROFIT</div><div class="sval" id="sTotal">$0.00</div></div>
  </div>
  <div class="filters">
    <button class="fbtn a" onclick="setFilter('all',this)">ALL</button>
    <button class="fbtn" onclick="setFilter('nfl',this)">NFL</button>
    <button class="fbtn" onclick="setFilter('nba',this)">NBA</button>
    <button class="fbtn" onclick="setFilter('mlb',this)">MLB</button>
    <button class="fbtn" onclick="setFilter('nhl',this)">NHL</button>
    <select class="sortsel" onchange="render()">
      <option value="pd">PROFIT ↓</option>
      <option value="pa">PROFIT ↑</option>
      <option value="t">SOONEST</option>
    </select>
  </div>
  <div class="lu" id="lu"></div>
  <div class="err" id="err"></div>
  <div id="out">
    <div class="center">
      <div class="empty-icon">◎</div>
      <div class="empty-title">READY TO SCAN</div>
      <div class="empty-sub">Paste your API key from <strong>the-odds-api.com</strong>, pick a sport, hit SCAN.</div>
    </div>
  </div>
</div>
<script>
let allArbs=[],curFilter='all',autoTimer=null,isAuto=false;
function dec(o){return o>0?o/100+1:100/Math.abs(o)+1}
function fmtOdds(o){return o>0?'+'+o:''+o}
function fmtTime(s){const d=new Date(s);return d.toLocaleDateString('en-US',{month:'short',day:'numeric'})+' '+d.toLocaleTimeString('en-US',{hour:'2-digit',minute:'2-digit'})}
function setDot(state){
  const dot=document.getElementById('dot'),sdot=document.getElementById('sdot'),stxt=document.getElementById('stxt');
  if(state==='scan'){dot.className='dot scan';sdot.style.cssText='background:#ff6b35;box-shadow:0 0 8px #ff6b35';stxt.textContent='SCANNING'}
  else if(state==='on'){dot.className='dot on';sdot.style.cssText='background:#00ff88;box-shadow:0 0 8px #00ff88';stxt.textContent=isAuto?'AUTO ON':'READY'}
  else{dot.className='dot';sdot.style.cssText='background:#333';stxt.textContent='IDLE'}
}
async function scan(){
  const key=document.getElementById('apiKey').value.trim();
  if(!key){showErr('Enter your Odds API key.');return}
  const sport=document.getElementById('sport').value;
  const stake=parseFloat(document.getElementById('stake').value)||100;
  setDot('scan');
  document.getElementById('scanBtn').disabled=true;
  document.getElementById('err').style.display='none';
  document.getElementById('out').innerHTML='<div class="spinner-wrap"><div class="spinner"></div><div class="spin-lbl">FETCHING LIVE ODDS...</div></div>';
  try{
    const resp=await fetch('/api/odds?apiKey='+encodeURIComponent(key)+'&sport='+sport);
    const data=await resp.json();
    if(!resp.ok)throw new Error(data.message||data.error||'API error '+resp.status);
    if(!Array.isArray(data))throw new Error('Unexpected response. Check your API key.');
    processGames(data,stake);
    const lu=document.getElementById('lu');lu.style.display='block';
    lu.textContent='UPDATED '+new Date().toLocaleTimeString()+(isAuto?' ● LIVE':'');
  }catch(e){showErr(e.message);render()}
  finally{setDot('on');document.getElementById('scanBtn').disabled=false}
}
function processGames(games,stake){
  allArbs=[];let markets=0;
  for(const g of games){
    const fd=g.bookmakers?.find(b=>b.key==='fanduel');
    const pin=g.bookmakers?.find(b=>b.key==='pinnacle');
    if(!fd||!pin)continue;
    const fH=fd.markets?.find(m=>m.key==='h2h');
    const pH=pin.markets?.find(m=>m.key==='h2h');
    if(!fH||!pH)continue;
    markets++;
    for(const fo of fH.outcomes){
      const po=pH.outcomes.find(o=>o.name!==fo.name);
      if(!po)continue;
      const fd2=dec(fo.price),pd2=dec(po.price),imp=1/fd2+1/pd2;
      if(imp<1){
        const margin=(1-imp)*100,s1=stake*(1/fd2)/imp,s2=stake*(1/pd2)/imp,payout=s1*fd2;
        allArbs.push({id:g.id+'_'+fo.name,event:g.home_team+' vs '+g.away_team,sport:g.sport_key,time:g.commence_time,margin,fdPick:fo.name,fdOdds:fo.price,pinPick:po.name,pinOdds:po.price,s1,s2,payout,profit:payout-stake});
        break;
      }
    }
  }
  document.getElementById('sArbs').textContent=allArbs.length;
  document.getElementById('sMarkets').textContent=markets;
  document.getElementById('sMax').textContent=(allArbs.length?Math.max(...allArbs.map(a=>a.margin)):0).toFixed(2)+'%';
  document.getElementById('sTotal').textContent='$'+allArbs.reduce((s,a)=>s+a.profit,0).toFixed(2);
  render();
}
function render(){
  const sort=document.querySelector('.sortsel').value;
  let list=[...allArbs].filter(a=>curFilter==='all'||a.sport.includes(curFilter));
  list.sort((a,b)=>sort==='pd'?b.margin-a.margin:sort==='pa'?a.margin-b.margin:new Date(a.time)-new Date(b.time));
  const out=document.getElementById('out');
  if(!list.length){out.innerHTML='<div class="center"><div class="empty-icon">◎</div><div class="empty-title">'+(allArbs.length?'NO ARBS FOR FILTER':'NO ARBS FOUND')+'</div><div class="empty-sub">'+(allArbs.length?'Try a different filter.':'No price gaps right now. Try AUTO to keep watching.')+'</div></div>';return}
  out.innerHTML='<div class="list">'+list.map((a,i)=>cardHTML(a,i)).join('')+'</div>';
}
function cardHTML(a,i){
  const hi=a.margin>2?'hi':'',fdc=a.fdOdds>0?'pos':'neg',pinc=a.pinOdds>0?'pos':'neg',sp=a.sport.split('_').pop().toUpperCase(),bid='cb_'+a.id.replace(/[^a-z0-9]/gi,'_');
  return '<div class="card" style="animation-delay:'+i*.04+'s"><div class="chead"><div class="profit '+hi+'">+'+a.margin.toFixed(2)+'%</div><div style="flex:1"><div class="evname">'+a.event+'</div><div class="evmeta"><span class="stag">'+sp+'</span><span class="ttime">⏱ '+fmtTime(a.time)+'</span></div></div></div>'
    +'<div class="legs"><div class="leg"><div class="book fd">▶ FANDUEL</div><div class="pick">'+a.fdPick+'</div><div class="odds-row"><div class="odds '+fdc+'">'+fmtOdds(a.fdOdds)+'</div><div class="stake-box"><div class="slb">STAKE</div><div class="sv">$'+a.s1.toFixed(2)+'</div></div></div></div>'
    +'<div class="leg"><div class="book pin">◆ PINNACLE</div><div class="pick">'+a.pinPick+'</div><div class="odds-row"><div class="odds '+pinc+'">'+fmtOdds(a.pinOdds)+'</div><div class="stake-box"><div class="slb">STAKE</div><div class="sv">$'+a.s2.toFixed(2)+'</div></div></div></div></div>'
    +'<div class="cfoot"><div class="psums"><div><div class="plbl">PROFIT</div><div class="pval g">+$'+a.profit.toFixed(2)+'</div></div><div><div class="plbl">STAKE</div><div class="pval">$'+(a.s1+a.s2).toFixed(2)+'</div></div><div><div class="plbl">PAYOUT</div><div class="pval">$'+a.payout.toFixed(2)+'</div></div><div><div class="plbl">ROI</div><div class="pval g">'+a.margin.toFixed(2)+'%</div></div></div>'
    +'<button class="copybtn" id="'+bid+'" onclick="copyBet(\''+a.id+'\')">⎘ COPY</button></div></div>';
}
function copyBet(id){
  const a=allArbs.find(x=>x.id===id);if(!a)return;
  navigator.clipboard?.writeText('ARB +'+a.margin.toFixed(2)+'%\n'+a.event+'\n\nFANDUEL: '+a.fdPick+' '+fmtOdds(a.fdOdds)+' — $'+a.s1.toFixed(2)+'\nPINNACLE: '+a.pinPick+' '+fmtOdds(a.pinOdds)+' — $'+a.s2.toFixed(2)+'\n\nProfit: +$'+a.profit.toFixed(2));
  const btn=document.getElementById('cb_'+id.replace(/[^a-z0-9]/gi,'_'));
  if(btn){btn.textContent='✓ COPIED';btn.classList.add('copied');setTimeout(()=>{btn.textContent='⎘ COPY';btn.classList.remove('copied')},2000)}
}
function setFilter(f,el){curFilter=f;document.querySelectorAll('.fbtn').forEach(b=>b.classList.remove('a'));el.classList.add('a');render()}
function toggleAuto(){
  const btn=document.getElementById('autoBtn');isAuto=!isAuto;
  if(isAuto){btn.textContent='⊗ STOP';btn.classList.add('on');scan();autoTimer=setInterval(scan,30000)}
  else{clearInterval(autoTimer);btn.textContent='⟳ AUTO';btn.classList.remove('on');setDot(allArbs.length?'on':'')}
}
function showErr(msg){const el=document.getElementById('err');el.textContent='⚠ '+msg;el.style.display='block'}
</script>
</body>
</html>`;
